var db = window.openDatabase("Exdata", "1.0", "Exercise database", 100000);

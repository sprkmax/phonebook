$('#add').on('pageinit', function() {
	$("#addnew").click(function (e) {
		
		var number = $('#number').val();
		var name = $('#name').val();
		var email = $('#email').val();
		
		db.transaction(addContact, errorCB, successCB);
		
		function addContact(db) {
			stmt = 'INSERT INTO CONTACTS (number, name, email) VALUES ('+number+','+name+','+email+')'
			db.executeSql(stmt);
		}

		// Transaction error callback
		//
		function errorCB(err) {
			alert("Error processing SQL: "+err);
		}

		// Transaction success callback
		//
		function successCB() {
			alert('contact added successfuly');
		}
	});
});

